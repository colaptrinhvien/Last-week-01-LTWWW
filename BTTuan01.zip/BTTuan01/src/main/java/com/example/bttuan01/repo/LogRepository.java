package com.example.bttuan01.repo;

public class LogRepository {
}
