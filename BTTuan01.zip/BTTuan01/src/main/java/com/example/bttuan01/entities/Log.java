package com.example.bttuan01.entities;

import java.time.LocalDate;

public class Log {
    private Account log_Account;
    private LocalDate log_In_Date;
    private LocalDate log_out_Date;
    private String note;

    public Log(Account log_Account, LocalDate log_In_Date, LocalDate log_out_Date, String note) {
        this.log_Account = log_Account;
        this.log_In_Date = log_In_Date;
        this.log_out_Date = log_out_Date;
        this.note = note;
    }

    public Account getLog_Account() {
        return log_Account;
    }

    public void setLog_Account(Account log_Account) {
        this.log_Account = log_Account;
    }

    public LocalDate getLog_In_Date() {
        return log_In_Date;
    }

    public void setLog_In_Date(LocalDate log_In_Date) {
        this.log_In_Date = log_In_Date;
    }

    public LocalDate getLog_out_Date() {
        return log_out_Date;
    }

    public void setLog_out_Date(LocalDate log_out_Date) {
        this.log_out_Date = log_out_Date;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Log{" +
                "log_Account=" + log_Account +
                ", log_In_Date=" + log_In_Date +
                ", log_out_Date=" + log_out_Date +
                ", note='" + note + '\'' +
                '}';
    }


}
